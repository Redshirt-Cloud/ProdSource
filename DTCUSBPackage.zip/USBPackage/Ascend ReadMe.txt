the ForensiTAzureID.xml file contains data for the organization

Do not separate the Profwiz.exe from the .xml file. They both need to be in the same directory when Profwiz.exe is ran.